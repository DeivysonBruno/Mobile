package deivyson.ufop.br.controlefinanceiro;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.MPPointF;

import java.util.ArrayList;

public class BalancoActivity extends AppCompatActivity {


    private PieChart chartReceita;
    private PieChart chartDespesa;
    private float[] valoresGraficoReceta={0,0,0,0,0};
    private float[] valoresGraficoDespesa={0,0,0,0,0,0,0};
    private String[] tiposReceita= {"Salário", "Aluguel", "Rendimentos", "Venda de Bens", "Outros"};
    private String[] tipoDespesas= {"Combustı́vel", "Vestuário", "Alimentação",  "Internet", "Água", "Luz", "Outros"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balanco);
        setTitle("Detalhes de contas");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        calculaEntradas();
        attGrafico();


    }
    public void attGrafico()
    {
        chartReceita = findViewById(R.id.chartReceitaid);
        chartReceita.setUsePercentValues(true);
        chartReceita.getDescription().setEnabled(false);
        chartReceita.setExtraOffsets(5, 10, 5, 5);
        chartReceita.setDragDecelerationFrictionCoef(0.95f);
        chartReceita.setDrawHoleEnabled(true);
        chartReceita.setHoleColor(Color.WHITE);
        chartReceita.setTransparentCircleColor(Color.WHITE);
        chartReceita.setTransparentCircleAlpha(110);
        chartReceita.setHoleRadius(56f);
        chartReceita.setTransparentCircleRadius(61f);
        chartReceita.setDrawCenterText(true);

        ArrayList<PieEntry> entries = new ArrayList<>();

        for(int i = 0; i<valoresGraficoReceta.length ; i++)
        {
            Log.d("CSI401", tiposReceita[i] + ": " + valoresGraficoReceta[i]);
            if(valoresGraficoReceta[i] == 0.0)
                continue;
            entries.add(new PieEntry((float)valoresGraficoReceta[i],
                    tiposReceita[i],
                    getResources().getDrawable(R.drawable.ic_add_black_24dp)));
            //System.out.print( valoresGraficoReceta[i]);
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setDrawIcons(false);
        dataSet.setSliceSpace(3f);
        dataSet.setIconsOffset(new MPPointF(0, 40));
        dataSet.setSelectionShift(5f);
        // add a lot of colors
        ArrayList<Integer> colors = new ArrayList<>();

        for (int c : ColorTemplate.VORDIPLOM_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.JOYFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.COLORFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.LIBERTY_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.PASTEL_COLORS)
            colors.add(c);

        colors.add(ColorTemplate.getHoloBlue());
        dataSet.setColors(colors);
        //dataSet.setSelectionShift(0f);
        PieData data = new PieData(dataSet);
        //data.setValueFormatter(new PercentFormatter(chart));
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.BLACK);

        chartReceita.setData(data);

        // undo all highlights
        chartReceita.highlightValues(null);

        chartReceita.invalidate();


        // chart Despesas

        chartDespesa = findViewById(R.id.Chartdespesas);
        chartDespesa.setUsePercentValues(true);
        chartDespesa.getDescription().setEnabled(false);
        chartDespesa.setExtraOffsets(5, 10, 5, 5);
        chartDespesa.setDragDecelerationFrictionCoef(0.95f);
        chartDespesa.setDrawHoleEnabled(true);
        chartDespesa.setHoleColor(Color.WHITE);
        chartDespesa.setTransparentCircleColor(Color.WHITE);
        chartDespesa.setTransparentCircleAlpha(110);
        chartDespesa.setHoleRadius(56f);
        chartDespesa.setTransparentCircleRadius(61f);
        chartDespesa.setDrawCenterText(true);
        ArrayList<PieEntry> entriesdesp = new ArrayList<>();
        for(int i = 0; i<valoresGraficoDespesa.length ; i++)
        {

            if(valoresGraficoDespesa[i] == 0.0)
                continue;
            entriesdesp.add(new PieEntry((float)valoresGraficoDespesa[i],
                    tipoDespesas[i],
                    getResources().getDrawable(R.drawable.ic_add_black_24dp)));
            //System.out.print( valoresGraficoReceta[i]);
        }

        PieDataSet dataSetDsp = new PieDataSet(entriesdesp, "");
        dataSetDsp.setDrawIcons(false);
        dataSetDsp.setSliceSpace(3f);
        dataSetDsp.setIconsOffset(new MPPointF(0, 40));
        dataSetDsp.setSelectionShift(5f);

        dataSetDsp.setColors(colors);
        //dataSet.setSelectionShift(0f);
        PieData dataDsp = new PieData(dataSetDsp);
        //data.setValueFormatter(new PercentFormatter(chart));
        dataDsp.setValueTextSize(11f);
        dataDsp.setValueTextColor(Color.BLACK);

        chartDespesa.setData(dataDsp);

        // undo all highlights
        chartDespesa.highlightValues(null);

        chartDespesa.invalidate();
    }
    public void calculaEntradas()

    {
        for(int i=0;i< valoresGraficoDespesa.length;i++)
        {
            valoresGraficoDespesa[i]=0;
        }
        for(int i=0;i< valoresGraficoReceta.length;i++)
        {
            valoresGraficoReceta[i]=0;
        }
        for(int i=0;i<RecursosCompartilhados.getInstance().getDespesasFiltrada().size();i++)
        {for(int j=0 ;j< tipoDespesas.length;j++){
            if(RecursosCompartilhados.getInstance().getDespesasFiltrada().get(i).getOrigem().equals(tipoDespesas[j]))
            {
                valoresGraficoDespesa[j] += (float)Float.parseFloat(RecursosCompartilhados.getDespesasFiltrada().get(i).getValor().toString());

            }
        }
        }

        for(int i=0;i<RecursosCompartilhados.getInstance().getReceitaFiltrada().size();i++)
        {for(int j=0 ;j< tiposReceita.length;j++){
            if(RecursosCompartilhados.getInstance().getReceitaFiltrada().get(i).getOrigem().equals(tiposReceita[j]))
            {
                valoresGraficoReceta[j] += (float)Float.parseFloat(RecursosCompartilhados.getReceitaFiltrada().get(i).getValor().toString());

            }
        }}



    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
