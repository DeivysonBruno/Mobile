package deivyson.ufop.br.controlefinanceiro;

import android.content.Context;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class RecursosCompartilhados {

    private static RecursosCompartilhados shared = null;

    //Singleton elements
    private static Calendar filtro;

    public static Calendar getFiltro() {
        return filtro;
    }

    public static void setFiltro(Calendar filtro) {
        RecursosCompartilhados.filtro = filtro;
    }

    private static ArrayList<Financa> receitas;
    private static ArrayList<Financa> despesas;
    private static ArrayList<Financa> receitaFiltrada;
    private static ArrayList<Financa> despesasFiltrada;
    private static ArrayList<EntradaGrafico> entrada;
    public static RecursosCompartilhados getInstance() {
        if(shared == null) {
            shared = new RecursosCompartilhados();
        }
        return shared;
    }

    private RecursosCompartilhados() {
        receitas = new ArrayList<Financa>();
        despesas = new ArrayList<Financa>();
        receitaFiltrada= new ArrayList<Financa>();
        despesasFiltrada = new ArrayList<Financa>();
        filtro= new GregorianCalendar();
        entrada = new ArrayList<EntradaGrafico>();
    }

    public static ArrayList<Financa> getReceitas() {
        return receitas;
    }

    public static ArrayList<Financa> getDespesas() {
        return despesas;
    }

    public static ArrayList<Financa> getReceitaFiltrada() {
        return receitaFiltrada;
    }

    public static ArrayList<Financa> getDespesasFiltrada() {
        return despesasFiltrada;
    }

    public void save(Context context) {
        try {
            FileOutputStream fos = context
                    .openFileOutput("receitas.dat",
                            Context.MODE_PRIVATE);
            ObjectOutputStream oos = new
                    ObjectOutputStream(fos);
            oos.writeObject(receitas);
            oos.close();


            FileOutputStream fos1 = context
                    .openFileOutput("despesas.dat",
                            Context.MODE_PRIVATE);
            ObjectOutputStream oos1 = new
                    ObjectOutputStream(fos1);
            oos1.writeObject(despesas);
            oos1.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void load(Context context) {
        try {
            FileInputStream fis = context
                    .openFileInput("receitas.dat");
            ObjectInputStream ois =
                    new ObjectInputStream(fis);
            receitas = (ArrayList<Financa>)
                    ois.readObject();
            ois.close();

            FileInputStream fis1 = context
                    .openFileInput("despesas.dat");
            ObjectInputStream ois1 =
                    new ObjectInputStream(fis1);
            despesas = (ArrayList<Financa>)
                    ois1.readObject();
            ois1.close();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public Double getTotalReceitas()
    {

        Double totalReceitas=0.0;
        for(int i=0;i< receitaFiltrada.size();i++)
        {
            totalReceitas+= receitaFiltrada.get(i).getValor();
        }
        return totalReceitas;
    }


    public Double getTotalDespesas()
    {

        Double totalDespesas=0.0;
        for(int i=0;i< despesasFiltrada.size();i++)
        {
            totalDespesas+= despesasFiltrada.get(i).getValor();
        }
        return totalDespesas;
    }

    public Double getBalanco()
    {
        return (getTotalReceitas()-getTotalDespesas());

    }
     public void filtraReceita(Calendar data)
     {

         receitaFiltrada= new ArrayList<Financa>();
         for(int i=0; i< receitas.size();i++){

             if(receitas.get(i).getD().get(Calendar.MONTH)== data.get(Calendar.MONTH)&& receitas.get(i).getD().get(Calendar.YEAR)==data.get(Calendar.YEAR))
             {
                 receitaFiltrada.add(receitas.get(i));
             }


         }



     }
    public void filtraDespesa(Calendar data)
    {

        despesasFiltrada = new ArrayList<Financa>();
        for(int i=0; i < despesas.size();i++){

            if(despesas.get(i).getD().get(Calendar.MONTH) == data.get(Calendar.MONTH)&& despesas.get(i).getD().get(Calendar.YEAR)==data.get(Calendar.YEAR))
            {
                despesasFiltrada.add(despesas.get(i));
            }


        }


    }
}
