package deivyson.ufop.br.controlefinanceiro;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class TelaCadastroDespesas extends AppCompatActivity {



    private DatePickerDialog dialogDatePicker;
    private EditText textDate;
    private DateFormat dateFormat;
    private EditText etValor;
    private Calendar calendar;
    private Spinner spinnerOrigem;
    private String origem = new String();
    private static final  String[] origens = {"Selecionar","Combustı́vel", "Vestuário", "Alimentação",  "Internet", "Água", "Luz","Outros"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
        setTitle("Cadastrar Despesa");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        calendar = new GregorianCalendar();
        calendar.setTimeZone(TimeZone.getDefault());
        dateFormat = DateFormat.getDateInstance();
        textDate = findViewById(R.id.textDateCadastro);
        textDate.setText(dateFormat.format(calendar.getTime()));



        spinnerOrigem= findViewById(R.id.origemSpinerIdADD);
        ArrayAdapter<String> adapterSpinner= new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,origens);

        spinnerOrigem.setAdapter(adapterSpinner);

        spinnerOrigem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                origem = origens[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        dialogDatePicker = new DatePickerDialog(this,
                AlertDialog.THEME_HOLO_LIGHT,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view,
                                          int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        //set textDate
                        textDate.setText(dateFormat.format(calendar.getTime()));
                    }
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));


        etValor = findViewById(R.id.valorIdAdd);



    }

    public void confirmarADD(View view) {

         if(origem.equals("Selecionar")||etValor.getText().toString().equals(""))
        {
            Toast.makeText(this, "Campos obrigatorios, favor preencher", Toast.LENGTH_SHORT).show();
            return;
        }
        Double valor = Double.parseDouble(etValor.getText().toString());

        Financa financa = new Financa(origem,valor,calendar);


        RecursosCompartilhados.getInstance().getDespesas().add(financa);
        Toast.makeText(this, "Despesa adicionada com sucesso", Toast.LENGTH_SHORT).show();
        spinnerOrigem.setSelection(0);
        etValor.setText("");

        RecursosCompartilhados.getInstance().save(getApplicationContext());
    }
    public void showDatePickerCadastro(View view) {
        dialogDatePicker.show();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
