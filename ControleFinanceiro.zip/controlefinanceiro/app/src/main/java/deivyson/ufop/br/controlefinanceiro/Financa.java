package deivyson.ufop.br.controlefinanceiro;

import java.io.Serializable;
import java.util.Calendar;

import deivyson.ufop.br.controlefinanceiro.Data;

public class Financa implements Serializable {

    private String origem;
    private Double valor;

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }






    private Calendar data;

    public Financa(String origem, Double valor, Calendar data) {
        this.origem = origem;
        this.valor = valor;
        this.data = data;
    }

    public Calendar getD() {
        return data;
    }

    public void setD(Calendar d) {
        this.data = d;
    }





    public int compareTo(Financa o) {
        if(this.data.equals(o.getD()) && this.origem.equals(o.getOrigem()) && this.valor.equals(o.getValor()))
        {
            return 0;
        }else if(this.getValor()>o.getValor())
        {
            return 1;
        }
        else
            {
                return -1;
            }
    }
}
