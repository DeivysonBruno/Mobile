package deivyson.ufop.br.controlefinanceiro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.Calendar;

public class ListaDespesas extends AppCompatActivity {

    private ListView lvDespesas;
    Calendar filtro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_receitas);
        lvDespesas =  findViewById(R.id.lvFinancas);
        setTitle("Lista de Despesas");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


    }

    @Override
    protected void onResume() {
        super.onResume();
        RecursosCompartilhados.getInstance().filtraDespesa(RecursosCompartilhados.getInstance().getFiltro());
        RecursosCompartilhados.getInstance().filtraReceita(RecursosCompartilhados.getInstance().getFiltro());
        lvDespesas.setAdapter(new FinanceiroAdapter(this, RecursosCompartilhados.getInstance().getDespesasFiltrada()));
        lvDespesas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent it = new Intent(
                        getApplicationContext(),
                        TelaEditDespesa.class);
                it.putExtra("position", position);
                startActivity(it);

            }
        });

    }

    public void abrirTelaCadastro(View view) {
        Intent it = new Intent(getApplicationContext(), TelaCadastroDespesas.class);

        startActivity(it);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
