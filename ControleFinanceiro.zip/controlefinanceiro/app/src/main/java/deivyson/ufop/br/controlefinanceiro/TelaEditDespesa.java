package deivyson.ufop.br.controlefinanceiro;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class TelaEditDespesa extends AppCompatActivity {


    private EditText etOrigem;
    private EditText etValor;

    private Financa financa;
    private int position;
    private Spinner spinnerOrigem;
    private String origem = new String();
    private int posSet;
    private static final  String[] origens = {"Selecionar","Combustı́vel", "Vestuário", "Alimentação", "Internet", "Água", "Luz"};

    private DatePickerDialog dialogDatePicker;
    private EditText textDate;
    private DateFormat dateFormat;

    private Calendar calendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_edit);
        setTitle("Editar Despesa");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        spinnerOrigem = findViewById(R.id.spinnerEdit);
        etValor = findViewById(R.id.valorIdEdit);
        calendar = new GregorianCalendar();
        calendar.setTimeZone(TimeZone.getDefault());
        dateFormat = DateFormat.getDateInstance();
        textDate = findViewById(R.id.textDateEdit);
        Intent it = getIntent();
        position = it.getIntExtra("position",0);
        financa = RecursosCompartilhados.getInstance().getDespesasFiltrada().get(position);
        calendar= financa.getD();
        dialogDatePicker = new DatePickerDialog(this,
                AlertDialog.THEME_HOLO_LIGHT,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view,
                                          int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        //set textDate
                        textDate.setText(dateFormat.format(calendar.getTime()));
                    }
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));



        for(int i=0 ;i<origens.length;i++)
        {
            if(financa.getOrigem().equals(origens[i]))
            {
                posSet= i;
            }

        }
        ArrayAdapter<String> adapterSpinner= new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,origens);

        spinnerOrigem.setAdapter(adapterSpinner);

        if(financa != null) {
            //Fill text fields
            spinnerOrigem.setSelection(posSet);
            etValor.setText(financa.getValor().toString());
            textDate.setText(dateFormat.format(financa.getD().getTime()));
        }
        spinnerOrigem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                origem = origens[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




    }

    public void confirmarEdit(View view) {
        if(origem.equals("Selecionar")||etValor.getText().toString().equals("") )
        {
            Toast.makeText(this, "Campos obrigatorios, favor preencher", Toast.LENGTH_SHORT).show();
            return;
        }
        financa.setOrigem(origem);
        financa.setValor(Double.parseDouble(etValor.getText().toString()));
        financa.setD(calendar);
        int pos= RecursosCompartilhados.getInstance().getDespesas().indexOf
                (RecursosCompartilhados.getInstance().getDespesasFiltrada().get(position));
        RecursosCompartilhados.getInstance().getDespesasFiltrada().set(position,financa);
        RecursosCompartilhados.getInstance().getDespesas().set(pos,financa);
        Toast.makeText(this, "Despesa editada com sucesso", Toast.LENGTH_SHORT).show();
        RecursosCompartilhados.getInstance().save(getApplicationContext());
        finish();

    }

    public void deleteRegistro(View view) {

        int pos= RecursosCompartilhados.getInstance().getDespesas().indexOf
                (RecursosCompartilhados.getInstance().getDespesasFiltrada().get(position));



        RecursosCompartilhados.getInstance().getDespesas().remove(pos);
        RecursosCompartilhados.getInstance().getDespesasFiltrada().remove(position);
        Toast.makeText(this, "Despesa Excluida com sucesso", Toast.LENGTH_SHORT).show();
        RecursosCompartilhados.getInstance().save(getApplicationContext());

        finish();
    }
    public void showDatePickerEdit(View view) {
        dialogDatePicker.show();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
