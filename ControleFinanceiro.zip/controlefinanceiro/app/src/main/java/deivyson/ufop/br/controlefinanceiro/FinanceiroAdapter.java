package deivyson.ufop.br.controlefinanceiro;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.ArrayList;

public class FinanceiroAdapter extends BaseAdapter {

    private Context context;
    private DateFormat dateFormat;

    private ArrayList<Financa> financas;


    @Override
    public int getCount() {
        return financas.size();
    }

    @Override
    public Object getItem(int position) {
        return financas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Financa financa= financas.get(position);
        dateFormat = DateFormat.getDateInstance();
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(
                R.layout.activity_financeiro_adapter, null);
        TextView tvOrigem = v.findViewById(R.id.origemIdAdapter);
        tvOrigem.setText(financa.getOrigem());

        TextView tvValor = v.findViewById(R.id.valorIdAdapter);
        tvValor.setText("R$ "+String.format ("%.2f",financa.getValor()));

        TextView tvData = v.findViewById(R.id.dataIdadapter);
        tvData.setText(dateFormat.format(financa.getD().getTime()));

        ImageView iv = v.findViewById(R.id.ImagAdpaterId);
        if(financa.getOrigem().equals("Combustı́vel")){

            iv.setImageResource(R.drawable.icons8_posto_de_gasolina_96);

        }else if(financa.getOrigem().equals("Água"))
        {
            iv.setImageResource(R.drawable.icons8_agua_80);

        }else if (financa.getOrigem().equals("Alimentação"))
        {
            iv.setImageResource(R.drawable.icons8_pao_64);

        }else if(financa.getOrigem().equals("Vestuário")){
            iv.setImageResource(R.drawable.icons8_camiseta_96);

        }else if (financa.getOrigem().equals("Internet"))
        {
            iv.setImageResource(R.drawable.icons8_internet_80);
        }
        else if(financa.getOrigem().equals("Luz"))
        {
            iv.setImageResource(R.drawable.icons8_eletrico_96);
        }
        else if(financa.getOrigem().equals("Salário"))
        {
            iv.setImageResource(R.drawable.icons8_pilha_de_dinheiro_96);

        }else if (financa.getOrigem().equals("Aluguel"))
        {
            iv.setImageResource(R.drawable.icons8_casa_96);
        }else if (financa.getOrigem().equals("Venda de Bens"))
        {
            iv.setImageResource(R.drawable.icons8_venda_de_terrenos_96);
        }else if (financa.getOrigem().equals("Rendimentos"))
        {
            iv.setImageResource(R.drawable.icons8_barras_de_ouro_96);
        }else if(financa.getOrigem().equals("Outros"))
        {
            iv.setImageResource(R.drawable.ic_all_inclusive_black_24dp);
        }



    return v;
    }

    public FinanceiroAdapter(Context context, ArrayList<Financa> financas) {
        this.context = context;
        this.financas = financas;
    }

}
