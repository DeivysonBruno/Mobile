    package deivyson.ufop.br.controlefinanceiro;

    import android.app.AlertDialog;
    import android.app.ProgressDialog;
    import android.content.Context;
    import android.content.DialogInterface;
    import android.content.Intent;
    import android.graphics.Color;
    import android.net.ConnectivityManager;
    import android.net.NetworkInfo;
    import android.os.AsyncTask;
    import android.support.v7.app.AppCompatActivity;
    import android.os.Bundle;
    import android.util.Log;
    import android.view.View;
    import android.widget.Button;
    import android.widget.TextView;
    import android.widget.Toast;

    import com.github.mikephil.charting.charts.PieChart;
    import com.github.mikephil.charting.data.PieData;
    import com.github.mikephil.charting.data.PieDataSet;
    import com.github.mikephil.charting.data.PieEntry;
    import com.github.mikephil.charting.utils.ColorTemplate;
    import com.github.mikephil.charting.utils.MPPointF;

    import org.json.JSONException;
    import org.json.JSONObject;

    import java.io.BufferedReader;
    import java.io.IOException;
    import java.io.InputStreamReader;
    import java.net.HttpURLConnection;
    import java.net.MalformedURLException;
    import java.net.ProtocolException;
    import java.net.URL;
    import java.security.KeyStore;
    import java.util.ArrayList;
    import java.util.Calendar;
    import java.util.GregorianCalendar;
    import java.util.List;
    import java.util.Map;
    import java.util.TimeZone;

    public class MainActivity extends AppCompatActivity {

        Button button;
        TextView tv;
        TextView tvdespesa;
        TextView tvReceita;
        TextView tvData;
        Calendar filtro;
        private ProgressDialog dialog;

        private TextView dolar, euro, iene, libras;
        private String dol, eu, ie, li;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            RecursosCompartilhados.getInstance().load(getApplicationContext());
            setContentView(R.layout.activity_main);
            tv= findViewById(R.id.grav);
            dolar=findViewById(R.id.idDolar);
            euro = findViewById(R.id.idEuro);
            iene = findViewById(R.id.idIene);
            libras= findViewById(R.id.idLibra);
            tvdespesa= findViewById(R.id.tvDespesasIdMain);
            tvReceita = findViewById(R.id.tvReceitasIdmain);
            filtro = new GregorianCalendar();
            dialog = new ProgressDialog(this);
            dialog.setMessage("Carregando Dados de cambio");



            filtro.setTimeZone(TimeZone.getDefault());
            tvData= findViewById(R.id.TVDataId);
            attFiltro(filtro.get(Calendar.MONTH));
            button = findViewById(R.id.butonbal);
            RecursosCompartilhados.getInstance().filtraDespesa(filtro);
            RecursosCompartilhados.getInstance().filtraReceita(filtro);




            ConnectivityManager connMgr = (ConnectivityManager)
                    getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                // limpa campos
               dialog.show();
                new DownloadCambioTask().execute();
                // obtem cep digitado




            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Sem Internet!")
                        .setMessage("Não há conexão de rede disponível!")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // nada
                            }
                        })
                        //.setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }



        }

        @Override
        protected void onResume() {
            super.onResume();


            RecursosCompartilhados.getInstance().filtraDespesa(filtro);
            RecursosCompartilhados.getInstance().filtraReceita(filtro);

            tvdespesa.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getTotalDespesas()));
            tvReceita.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getTotalReceitas()));
            if(RecursosCompartilhados.getInstance().getBalanco()<0)
            {
                tv.setTextColor(Color.RED);
                tv.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getBalanco()));

            }else
            {

                tv.setTextColor(getResources().getColor(R.color.colorGreen));
                tv.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getBalanco()));
            }

        }

        public void abrirListaReceitas(View view) {
            Intent it = new Intent(getApplicationContext(), ListaReceitas.class);
            it.putExtra("data",filtro);
            startActivity(it);


        }

        public void abrirListaDespesas(View view) {
            Intent it = new Intent(getApplicationContext(), ListaDespesas.class);
            it.putExtra("data",filtro);
            startActivity(it);
        }

        public void abrirBalanco(View view) {
            Intent it = new Intent(getApplicationContext(), BalancoActivity.class);

            startActivity(it);
        }


        public void avançaFiltro(View view) {
                    filtro.set(Calendar.MONTH, filtro.get(Calendar.MONTH)+1);
                    attFiltro(filtro.get(Calendar.MONTH));
                    RecursosCompartilhados.getInstance().filtraDespesa(filtro);
                    RecursosCompartilhados.getInstance().filtraReceita(filtro);


            tvdespesa.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getTotalDespesas()));
            tvReceita.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getTotalReceitas()));
            if(RecursosCompartilhados.getInstance().getBalanco()<0)
            {
                tv.setTextColor(Color.RED);
                tv.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getBalanco()));

            }else
            {

                tv.setTextColor(getResources().getColor(R.color.colorGreen));
                tv.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getBalanco()));
            }

        }

        public void atrasarFiltro(View view) {

                filtro.set(Calendar.MONTH, filtro.get(Calendar.MONTH)-1);
                attFiltro(filtro.get(Calendar.MONTH));
            RecursosCompartilhados.getInstance().filtraDespesa(filtro);
            RecursosCompartilhados.getInstance().filtraReceita(filtro);



            tvdespesa.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getTotalDespesas()));
            tvReceita.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getTotalReceitas()));
            if(RecursosCompartilhados.getInstance().getBalanco()<0)
            {
                tv.setTextColor(Color.RED);

                tv.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getBalanco()));

            }else
            {


                tv.setTextColor(getResources().getColor(R.color.colorGreen));
                tv.setText("R$"+String.format("%.2f",RecursosCompartilhados.getInstance().getBalanco()));
            }
        }

        private void attFiltro(int a)
        {

            RecursosCompartilhados.getInstance().setFiltro(filtro);
            if(a ==0)
            {
                tvData.setText("Jan/"+filtro.get(Calendar.YEAR));
            }
            if(a ==1)
            {
                tvData.setText("Fev/"+filtro.get(Calendar.YEAR));
            }
            if( a ==2) {
                tvData.setText("Mar/"+filtro.get(Calendar.YEAR));
            }
            if( a ==3) {
                tvData.setText("Abr/"+filtro.get(Calendar.YEAR));
            }
            if(a == 4)
            {
                tvData.setText("Mai/"+filtro.get(Calendar.YEAR));
            }
            if( a == 5)
            {
                tvData.setText("Jun/"+filtro.get(Calendar.YEAR));
            }
            if(a ==6)
            {
                tvData.setText("Jul/"+filtro.get(Calendar.YEAR));
            }
            if(a ==7)
            {
                tvData.setText("Ago/"+filtro.get(Calendar.YEAR));
            }
            if(a ==8)
            {
                tvData.setText("Set/"+filtro.get(Calendar.YEAR));
            }
            if(a ==9)
            {
                tvData.setText("Out/"+filtro.get(Calendar.YEAR));
            }
            if(a ==10)
            {
                tvData.setText("Nov/"+filtro.get(Calendar.YEAR));
            }
            if(a == 11)
            {
                tvData.setText("Dez/"+filtro.get(Calendar.YEAR));
            }



        }

        public class DownloadCambioTask extends AsyncTask<String, Void, DadosCambio> {
            @Override
            protected DadosCambio doInBackground(String ... Dados) {
                DadosCambio dadosCambio = null;

                try {
                    dadosCambio = new DadosCambio(MainActivity.this);
                } finally {
                    dialog.dismiss();
                    return dadosCambio;
                }
            }



            @Override
            protected void onPostExecute(DadosCambio result) {
                Log.d("csi401",""+ result.isEncontrou());
                if (result != null && result.isEncontrou()) {
                    Log.d("csi401",""+ result.isEncontrou());
                    dolar.setText("R$"+ String.format("%.2f",(1/Double.parseDouble(result.getDolar()))));
                    euro.setText( "R$"+String.format("%.2f",(1/Double.parseDouble(result.getEuro()))));
                    libras.setText("R$ "+ String.format("%.2f",(1/Double.parseDouble(result.getLibras()))));
                    iene.setText("R$ "+ String.format("%.2f",(1/Double.parseDouble(result.getIene()))));

                }
                else
                    Toast.makeText(MainActivity.this, "Os dados nao foram encontrados!", Toast.LENGTH_SHORT).show();
            }

        }




    }


