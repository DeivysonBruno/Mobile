package deivyson.ufop.br.controlefinanceiro;

public class EntradaGrafico {
    float valor;
    String tipo;

    public EntradaGrafico(float valor, String tipo) {
        this.valor = valor;
        this.tipo = tipo;
    }

    public float getValor() {

        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
