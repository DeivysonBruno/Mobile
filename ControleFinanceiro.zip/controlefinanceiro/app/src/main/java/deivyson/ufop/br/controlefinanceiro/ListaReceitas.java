package deivyson.ufop.br.controlefinanceiro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class ListaReceitas extends AppCompatActivity {

    private ListView lvReceitas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_receitas);
        lvReceitas =  findViewById(R.id.lvFinancas);
        setTitle("Lista de Receitas");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


    }

    @Override
    protected void onResume() {
        super.onResume();
        RecursosCompartilhados.getInstance().filtraDespesa(RecursosCompartilhados.getInstance().getFiltro());
        RecursosCompartilhados.getInstance().filtraReceita(RecursosCompartilhados.getInstance().getFiltro());
        lvReceitas.setAdapter(new FinanceiroAdapter(this, RecursosCompartilhados.getInstance().getReceitaFiltrada()));
        lvReceitas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent it = new Intent(
                        getApplicationContext(),
                        TelaEditReceita.class);
                it.putExtra("position", position);
                startActivity(it);

            }
        });

    }
    public void abrirTelaCadastro(View view)
    {
        Intent it = new Intent(getApplicationContext(), TelaCadastroReceita.class);

        startActivity(it);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
